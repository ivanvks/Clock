#include "tcpserver.h"

TcpServer::TcpServer(QObject *parent)
    : QObject(parent),
      server(nullptr),
      socket(nullptr)
{

}

void TcpServer::initServer()
{
    server = new QTcpServer(this);

    connect(server, &QTcpServer::newConnection, this, &TcpServer::onNewConnection);

    if (server->listen(QHostAddress::Any, 11125))
    {
        qDebug() << "Server listening on port 11125";
    }
    else
    {
        qDebug() << "Failed to start server:" << server->errorString();
    }
}

void TcpServer::onNewConnection()
{
    qDebug() << "New connection established";

    if (socket)
    {
        socket->disconnectFromHost();
        socket->deleteLater();
    }

    socket = server->nextPendingConnection();
    connect(socket, &QTcpSocket::readyRead, this, &TcpServer::processReadyRead);
}

void TcpServer::processReadyRead()
{
    if (socket && socket->isValid())
    {
        QByteArray data = socket->readAll();
        qDebug() << "Received data from client:" << data;
    }
}
////TCP-сервером и сокетом,  добавляю методы closeConnection() для класса TcpServer и TcpSocket. 



// Для TcpServer
void TcpServer::closeConnection()
{
    if (socket && socket->isValid())
    {
        socket->disconnectFromHost();
        socket->close();
        socket->deleteLater();
    }
}

// Для TcpSocket
void TcpSocket::closeConnection()
{
    if (socket && socket->isValid())
    {
        socket->disconnectFromHost();
        socket->close();
        socket->deleteLater();
    }
}

Эти методы позволяют корректно закрыть сокет и освободить связанные с ним ресурсы.

Когда вызывается deleteLater(), объект не уничтожается мгновенно, а добавляется в очередь на удаление и будет удален во время следующего цикла обработки событий.  можно использовать delete:


// Для TcpServer
void TcpServer::closeConnection()
{
    if (socket && socket->isValid())
    {
        socket->disconnectFromHost();
        socket->close();
        delete socket;
        socket = nullptr;
    }
}

// Для TcpSocket
void TcpSocket::closeConnection()
{
    if (socket && socket->isValid())
    {
        socket->disconnectFromHost();
        socket->close();
        delete socket;
        socket = nullptr;
    }
}

после вызова delete, указатель socket устанавливается в nullptr, чтобы избежать обращения к удаленному объекту.
,,,,,,,,,,,,,,,,,,,,,,,,,..,,,,,,,,,,,,,......................./////////////////////////////////////////////////////////////////////


///проверка ошибок..................////////


void UdpSocket::~UdpSocket()
{
    qDebug() << "Закрытие сокета выполнено успешно!";

    // Соединяем сигнал destroyed с собственным слотом для удаления сокета
    connect(socket, &QObject::destroyed, socket, &QObject::deleteLater);

    socket->close();
    // Отключаем все слоты и сигналы, чтобы избежать их вызова после deleteLater
    disconnect(socket, nullptr, nullptr, nullptr);
}

Проверка наличия ошибок: можно добавить код для проверки наличия ошибок при связывании сокета. :


bool result = socket->bind(QHostAddress::AnyIPv4, 11125);
if (result)
{
    qDebug() << "Socket PASS";
}
else
{
    qDebug() << "Socket FAIL" << socket->errorString();
}

Обработка ошибок в методе чтения датаграммы: В вашем методе processPendingDatagrams, вы можете добавить обработку ошибок при чтении датаграммы. 


while (socket->hasPendingDatagrams())
{
    QByteArray datagram;
    datagram.resize(socket->pendingDatagramSize());
    qint64 bytesRead = socket->readDatagram(datagram.data(), datagram.size(), &sender, &port);

    if (bytesRead == -1)
    {
        qDebug() << "Error reading datagram:" << socket->errorString();
        return;
    }

    qDebug() << "Message From :: " << sender.toString();
    qDebug() << "Port From :: " << port;
    qDebug() << "Message :: " << datagram;
}
/////////////////////////////////////