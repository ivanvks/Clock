#include <QApplication>
#include <QMainWindow>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QVBoxLayout>
#include <QDateTime>
#include "mainwindow.h"


MyMainWindow::MyMainWindow(int messageCount) : QMainWindow() {
        setupUI(messageCount);
    }

void MyMainWindow::setupUI(int messageCount) {
        // Создание основного виджета
        QWidget *centralWidget = new QWidget(this);
        setCentralWidget(centralWidget);

        // Создание TableWidget
        QTableWidget *tableWidget = new QTableWidget(0, 8, this);
        QStringList headerLabels = {"Отправитель", "Получатель", "Дата и время отправки",
                                    "Наименование", "Дата и время получения", "Статус",
                                    "Дата и время прочтения", "Комментарии"};
        tableWidget->setHorizontalHeaderLabels(headerLabels);

        // Добавление строк в TableWidget
        for (int i = 0; i < messageCount; ++i) {
            int row = tableWidget->rowCount();
            tableWidget->insertRow(row);

            // Пример заполнения данными
            tableWidget->setItem(row, 0, new QTableWidgetItem("Отправитель " + QString::number(i + 1)));
            tableWidget->setItem(row, 1, new QTableWidgetItem("Получатель " + QString::number(i + 1)));
            tableWidget->setItem(row, 2, new QTableWidgetItem(QDateTime::currentDateTime().toString()));
            tableWidget->setItem(row, 3, new QTableWidgetItem("Наименование " + QString::number(i + 1)));
            tableWidget->setItem(row, 4, new QTableWidgetItem(""));
            tableWidget->setItem(row, 5, new QTableWidgetItem("Не прочитано"));
            tableWidget->setItem(row, 6, new QTableWidgetItem(""));
            tableWidget->setItem(row, 7, new QTableWidgetItem(""));
            tableWidget->setItem(row, 8, new QTableWidgetItem("Комментарии " + QString::number(i + 1)));
        }
        // Автоматическая подгонка ширины колонок
        tableWidget->resizeColumnsToContents();

        // Создание и настройка основного макета
        QVBoxLayout *layout = new QVBoxLayout(centralWidget);
        layout->addWidget(tableWidget);

        // Установка основного макета
        centralWidget->setLayout(layout);
    }


