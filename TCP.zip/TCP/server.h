#ifndef TCPSERVER_H
#define TCPSERVER_H

#include <QObject>
#include <QTcpServer>
#include <QTcpSocket>

class TcpServer : public QObject
{
    Q_OBJECT

    QTcpServer *server;
    QTcpSocket *socket;

public:
    explicit TcpServer(QObject *parent = nullptr);

    void initServer();

private slots:
    void onNewConnection();
    void processReadyRead();
};

#endif // TCPSERVER_H
