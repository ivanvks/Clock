#ifndef CSQLDATABASE_H
#define CSQLDATABASE_H


class CSqlDatabase
{
public:
    CSqlDatabase();
};

#endif // CSQLDATABASE_H
