// server.cpp
#include "server.h"

Server::Server(QObject *parent) : QTcpServer(parent)
{
    socket = nullptr;
}

void Server::incomingConnection(qintptr socketDescriptor)
{
    // Устанавливаем соединение с новым сокетом
    socket = new QTcpSocket(this);
    socket->setSocketDescriptor(socketDescriptor);

    // Подключаем сигналы/слоты для обработки данных
    connect(socket, SIGNAL(readyRead()), this, SLOT(readData()));
    connect(socket, SIGNAL(disconnected()), this, SLOT(disconnectClient()));

    qDebug() << "Client connected";
}

void Server::readData()
{
    if (socket && socket->isValid())
    {
        QByteArray data = socket->readAll();
        // Обработка данных от клиента
        qDebug() << "Received data from client:" << data;
    }
}

void Server::disconnectClient()
{
    if (socket && socket->isValid())
    {
        // Обработка отключения клиента
        qDebug() << "Client disconnected";
        socket->deleteLater();
    }
}
