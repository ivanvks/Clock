// client.cpp
#include "client.h"

Client::Client(QObject *parent) : QTcpSocket(parent)
{
    connect(this, SIGNAL(connected()), this, SLOT(onConnected()));
    connect(this, SIGNAL(disconnected()), this, SLOT(onDisconnected()));
    connect(this, SIGNAL(readyRead()), this, SLOT(onReadyRead()));
}

void Client::connectToServer()
{
    // Устанавливаем соединение с сервером
    connectToHost("127.0.0.1", 12345);
}

void Client::onConnected()
{
    qDebug() << "Connected to server";
}

void Client::onDisconnected()
{
    qDebug() << "Disconnected from server";
}

void Client::onReadyRead()
{
    if (isValid())
    {
        QByteArray data = readAll();
        // Обработка данных от сервера
        qDebug() << "Received data from server:" << data;
    }
}
