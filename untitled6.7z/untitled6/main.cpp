#include "mainwindow.h"

#include <QApplication>

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    // Количество входящих сообщений
    int messageCount = 55;

    MyMainWindow mainWindow(messageCount);
    mainWindow.show();

    return app.exec();
}
