#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>

void createArchive(const std::string& directory, const std::string& outputArchive, const std::string& password) {
    // Создаем архив
    std::string command = "7z a " + outputArchive + " " + directory;
    system(command.c_str());

    // Создаем файл с программой для проверки пароля и удаления содержимого
    std::ofstream selfDestruct("self_destruct.cpp");
    selfDestruct << "#include <iostream>\n"
                 << "#include <string>\n"
                 << "#include <cstdlib>\n"
                 << "#include <windows.h>\n"
                 << "int main() {\n"
                 << "    int attemptsCounter = 0;\n"
                 << "    while (attemptsCounter < 10) {\n"
                 << "        std::string passwordAttempt;\n"
                 << "        std::cout << \"Введите пароль для архива: \";\n"
                 << "        std::cin >> passwordAttempt;\n"
                 << "        if (passwordAttempt == \"" << password << "\") {\n"
                 << "            std::cout << \"Пароль верный.\\n\";\n"
                 << "            return 0;\n"
                 << "        } else {\n"
                 << "            std::cout << \"Неправильный пароль.\\n\";\n"
                 << "            attemptsCounter++;\n"
                 << "        }\n"
                 << "    }\n"
                 << "    if (attemptsCounter == 10) {\n"
                 << "        system(\"7z x " << outputArchive << "\");\n"
                 << "        DeleteFileA(\"" << outputArchive << "\");\n"
                 << "        std::remove(\"self_destruct.exe\");\n"
                 << "        std::cout << \"Содержимое архива удалено.\\n\";\n"
                 << "    }\n"
                 << "    return 0;\n"
                 << "}\n";
    selfDestruct.close();

    // Компилируем программу для проверки пароля
    command = "g++ self_destruct.cpp -o self_destruct.exe";
    system(command.c_str());
}

int main() {
    createArchive("directory_to_archive", "archive.7z", "password123");
    return 0;
}
