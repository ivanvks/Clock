#include <QCoreApplication>

#include "udpserver.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    auto udpServer = new UdpServer();
    udpServer->initSocket();

    return a.exec();
}
