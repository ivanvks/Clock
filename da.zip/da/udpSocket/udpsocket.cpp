#include "udpsocket.h"
#include <QDir>


UdpSocket::UdpSocket(QObject *parent)
    : QObject(parent)
{
    qDebug() << "Зашли в конструктор класса UdpSocket" ;
    //mUdpSocket_ = new QUdpSocket(this);
    socket = new QUdpSocket(this);
    mCheckXml_ = new QFileSystemWatcher(this); /// инициализируем  проверку сообщений XML
    /// соединяем сигнал/слот проверки сообщений XML
    connect( mCheckXml_, SIGNAL( directoryChanged(QString) ), this, SLOT( HelloUDP(QString) ) );
    /// Запускаем подписку на notify сигналы мониторинга локальной директории для xml
    qDebug() << "Konstruktor";
    startXml();
}
UdpSocket::~UdpSocket()
{
    qDebug() << "Закрытие сокета выполнено успешно!";

    socket->close();
    socket->deleteLater();
}

void UdpSocket::HelloUDP(const QString &mess)
{
    qDebug()<<mess;
    QDir fils(mess);
    fils.entryInfoList();
    qDebug()<<fils.entryInfoList();
    QFile file( QString::fromLocal8Bit("/home/ivan/sXML/vfsvReport.xml" ) );
    //"/home/ivan/sXML/vfsvReport.xml"

    if (!file.open(QIODevice::ReadOnly))
    qDebug() << file.errorString();

    QByteArray data(file.readAll());
    qDebug() << __PRETTY_FUNCTION__ << "send =>" << data;
    file.close();
    file.flush();
    file.remove();
    QHostAddress addr( "127.0.0.1" );
    quint16 port( 11125 );
   // mUdpSocket_->writeDatagram( data, addr, port );

    qDebug() << socket->writeDatagram(data, addr, port);
}

/// Запуск прослушки локальной директории
void UdpSocket::startXml()
{
    if (mCheckXml_->addPath("/home/ivan/sXML")){
    qDebug() << "Подписка на события в локальной директории запущена!";
    }
}

