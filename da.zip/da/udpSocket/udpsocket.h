#ifndef UDPSOCKET_H
#define UDPSOCKET_H

#include <QFile>
#include <QObject>
#include <QUdpSocket>
#include <QFileSystemWatcher>


class UdpSocket : public QObject
{
    Q_OBJECT
    //QUdpSocket            *mUdpSocket_;
    /// таймер проверки сообщений XML
    QFileSystemWatcher    *mCheckXml_;

    QUdpSocket *socket = nullptr;
private:
    /**
     * @brief startXml - Запуск проверки сообщений XML
     */
    void startXml();
//    *
//     * @brief fileReaderSV - Cчитываем содержимое файла
//     * @param name       - наименомание файла
//     * @return           - содержимое файла
//     */
//    QByteArray fileReaderSV( const QString &name );
//    /**
//     * @brief fileReaderVP - Cчитываем содержимое файла
//     * @param name       - наименомание файла
//     * @return           - содержимое файла
//     */
//    QByteArray fileReaderVP( const QString &name );
//    /**
//     * @brief fileWriter - Записываем содержимое файла
//     * @param data       - содержимое файла
//     * @param name       - наименомание файла


public:
    explicit UdpSocket(QObject *parent = nullptr);
    ~UdpSocket();

public slots:
     void HelloUDP(const QString &mess);
//    /**
//     * @brief checkViaXml - Проверка сообщений XML
//     */
//    void checkViaXml();

};

#endif // UDPSOCKET_H
