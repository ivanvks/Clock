#include "csqldatabase.h"

CSqlDatabase::CSqlDatabase()
{

}
