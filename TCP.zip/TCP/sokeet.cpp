#include "tcpsocket.h"
#include <QDir>

TcpSocket::TcpSocket(QObject *parent)
    : QObject(parent)
{
    qDebug() << "Зашли в конструктор класса TcpSocket";
    socket = new QTcpSocket(this);
    mCheckXml_ = new QFileSystemWatcher(this);

    // соединяем сигнал/слот проверки сообщений XML
    connect(mCheckXml_, SIGNAL(directoryChanged(QString)), this, SLOT(HelloTCP(QString)));

    // Запускаем подписку на notify сигналы мониторинга локальной директории для xml
    qDebug() << "Konstruktor";
    startXml();
}

TcpSocket::~TcpSocket()
{
    qDebug() << "Закрытие сокета выполнено успешно!";
    if (socket->isOpen()) {
        socket->disconnectFromHost();
        socket->close();
    }
    socket->deleteLater();
}

void TcpSocket::HelloTCP(const QString &mess)
{
    qDebug() << mess;
    QDir fils(mess);
    fils.entryInfoList();
    qDebug() << fils.entryInfoList();

    QFile file(QString::fromLocal8Bit("/home/ivan/sXML/vfsvReport.xml"));

    if (!file.open(QIODevice::ReadOnly))
        qDebug() << file.errorString();

    QByteArray data(file.readAll());
    qDebug() << __PRETTY_FUNCTION__ << "send =>" << data;
    file.close();
    file.flush();
    file.remove();

    QHostAddress addr("127.0.0.1");
    quint16 port = 11125;

    if (!socket->isOpen()) {
        socket->connectToHost(addr, port);
        if (!socket->waitForConnected(5000)) {
            qDebug() << "Error connecting to server:" << socket->errorString();
            return;
        }
    }

    qDebug() << socket->write(data);
}

void TcpSocket::startXml()
{
    if (mCheckXml_->addPath("/home/ivan/sXML")) {
        qDebug() << "Подписка на события в локальной директории запущена!";
    }
}
