#ifndef MYMAINWINDOW_H
#define MYMAINWINDOW_H

#include <QMainWindow>

class MyMainWindow : public QMainWindow {
public:
    MyMainWindow(int messageCount, const QStringList& properties, const QStringList& values);

private:
    void setupUI(int messageCount, const QStringList& properties, const QStringList& values);
    //QString getValueForProperty(const QString &property) const;
};

#endif // MYMAINWINDOW_H
