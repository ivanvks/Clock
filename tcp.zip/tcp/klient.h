// client.h
#ifndef CLIENT_H
#define CLIENT_H

#include <QTcpSocket>

class Client : public QTcpSocket
{
    Q_OBJECT

public:
    Client(QObject *parent = 0);

public slots:
    void connectToServer();
    void onConnected();
    void onDisconnected();
    void onReadyRead();
};

#endif // CLIENT_H
