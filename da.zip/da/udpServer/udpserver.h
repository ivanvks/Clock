#ifndef UDPSERVER_H
#define UDPSERVER_H

#include <QObject>
#include <QUdpSocket>

class UdpServer : public QObject
{
    Q_OBJECT

    QUdpSocket *socket = nullptr;

public:
    explicit UdpServer(QObject *parent = nullptr);

    void initSocket();

private slots:
    void processPendingDatagrams();

};

#endif // UDPSERVER_H
