#include "udpserver.h"

UdpServer::UdpServer(QObject *parent)
    : QObject{parent}
{

}

void UdpServer::initSocket()
{
    socket = new QUdpSocket(this);
    bool result =  socket->bind(QHostAddress::AnyIPv4, 11125);
    if(result)
    {
        qDebug() << "Socket PASS";
    }
    else
    {
        qDebug() << "Socket FAIL";
    }

//    processPendingDatagrams();
    connect(socket, &QUdpSocket::readyRead, this, &UdpServer::processPendingDatagrams);
}

void UdpServer::processPendingDatagrams()
{
    qDebug() << "in !";
    QHostAddress sender;
    quint16 port;
    while (socket->hasPendingDatagrams())
    {
        QByteArray datagram;
        datagram.resize(socket->pendingDatagramSize());
        socket->readDatagram(datagram.data(),datagram.size(),&sender,&port);
        qDebug() <<"Message From :: " << sender.toString();
        qDebug() <<"Port From :: "<< port;
        qDebug() <<"Message :: " << datagram;
    }
}
