#include <QCoreApplication>
//#include <QApplication>

#include "udpsocket.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    auto udpServer = new UdpSocket();
//    udpServer->HelloUDP(  &data);

    return a.exec();
    exit(0);
}
