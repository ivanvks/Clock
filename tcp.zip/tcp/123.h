// server.h
#ifndef SERVER_H
#define SERVER_H

#include <QTcpServer>
#include <QTcpSocket>

class Server : public QTcpServer
{
    Q_OBJECT

public:
    Server(QObject *parent = 0);

protected:
    void incomingConnection(qintptr socketDescriptor) override;

private slots:
    void readData();
    void disconnectClient();

private:
    QTcpSocket *socket;
};

#endif // SERVER_H
