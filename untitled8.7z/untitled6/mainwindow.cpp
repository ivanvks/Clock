#include <QApplication>
#include <QMainWindow>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QVBoxLayout>
#include <QDateTime>
#include <QLabel>
#include "mainwindow.h"


MyMainWindow::MyMainWindow(int messageCount, const QStringList &properties, const QStringList &values) : QMainWindow() {
        setupUI(messageCount, properties, values);
    }

void MyMainWindow::setupUI(int messageCount, const QStringList& properties, const QStringList& values){
        // Создание основного виджета
//        QWidget *centralWidget = new QWidget(this);
//        setCentralWidget(centralWidget);

//        // Создание TableWidget
//        QTableWidget *tableWidget = new QTableWidget(0, 8, this);
//        QStringList headerLabels = {"Номер", "Лицо", "Дата и время отправки",
//                                    "Наименование", "Дата и время получения", "Статус",
//                                    "Дата и время прочтения", "Комментарии"};
//        tableWidget->setVerticalHeaderLabels(headerLabels);

//        // Добавление строк в TableWidget
//        for (int i = 0; i < messageCount; ++i) {
//            int row = tableWidget->rowCount();
//            tableWidget->insertRow(row);

//            // Пример заполнения данными
//            tableWidget->setItem(row, 0, new QTableWidgetItem("Отправитель " + QString::number(i + 1)));
//            tableWidget->setItem(row, 1, new QTableWidgetItem("Получатель " + QString::number(i + 1)));
//            tableWidget->setItem(row, 2, new QTableWidgetItem(QDateTime::currentDateTime().toString()));
//            tableWidget->setItem(row, 3, new QTableWidgetItem("Наименование " + QString::number(i + 1)));
//            tableWidget->setItem(row, 4, new QTableWidgetItem(""));
//            tableWidget->setItem(row, 5, new QTableWidgetItem("Не прочитано"));
//            tableWidget->setItem(row, 6, new QTableWidgetItem(""));
//            tableWidget->setItem(row, 7, new QTableWidgetItem(""));
//            tableWidget->setItem(row, 8, new QTableWidgetItem("Комментарии " + QString::number(i + 1)));
//        }
//        // Автоматическая подгонка ширины колонок
//        tableWidget->resizeColumnsToContents();

//        // Создание и настройка основного макета
//        QVBoxLayout *layout = new QVBoxLayout(centralWidget);
//        layout->addWidget(tableWidget);

//        // Установка основного макета
//        centralWidget->setLayout(layout);
//    }

  // Создание основного виджета
//        QWidget *centralWidget = new QWidget(this);
//        setCentralWidget(centralWidget);

//        // Создание TableWidget с двумя колонками
//        QTableWidget *tableWidget = new QTableWidget(0, 2, this);
//        QStringList headerLabels = {"Свойство", "Значение"};
//        tableWidget->setHorizontalHeaderLabels(headerLabels);

//        // Свойства и значения

//        QStringList properties2 = {"Вася", "Петя", "Дата и время отправки",
//                                  "Наименование", "Дата и время получения", "Статус",
//                                  "Дата и время прочтения", "Комментарии"};
//        // Добавление свойств и значений в TableWidget
//        for (const QString &property : properties2) {
//            int row = tableWidget->rowCount();
//            tableWidget->insertRow(row);

//            // Лейбл для свойства
//            QLabel *propertyLabel = new QLabel(property);
//            tableWidget->setCellWidget(row, 0, propertyLabel);

//
//           // QTableWidgetItem *valueItem = new QTableWidgetItem("Значение " + property);
//            //tableWidget->setItem(row, 1, valueItem);
//            tableWidget->setItem(row, 1, new QTableWidgetItem("555 " ));
//            tableWidget->setItem(row, 2, new QTableWidgetItem("888 " ));
//            tableWidget->setItem(row, 3, new QTableWidgetItem("333 " ));
//        }

//        // Автоматическая подгонка ширины колонок
//        tableWidget->resizeColumnsToContents();

//        // Создание и настройка основного макета
//        QVBoxLayout *layout = new QVBoxLayout(centralWidget);
//        layout->addWidget(tableWidget);

//        // Установка основного макета
//        centralWidget->setLayout(layout);
//    }
        /////РАБОТАЕТ
//        QWidget *centralWidget = new QWidget(this);
//        setCentralWidget(centralWidget);

//        // Создание TableWidget с двумя колонками
//        QTableWidget *tableWidget = new QTableWidget(0, 2, this);
//        QStringList headerLabels = {"Свойство", "Значение"};
//        tableWidget->setHorizontalHeaderLabels(headerLabels);

//        // Свойства и значения
//        QStringList properties = {"Вася", "Петя", "Дата и время отправки",
//                                  "Наименование", "Дата и время получения", "Статус",
//                                  "Дата и время прочтения", "Комментарии"};

//        // Добавление свойств и значений в TableWidget
//        for (const QString &property : properties) {
//            int row = tableWidget->rowCount();
//            tableWidget->insertRow(row);

//            // Лейбл для свойства
//            QLabel *propertyLabel = new QLabel(property);
//            tableWidget->setCellWidget(row, 0, propertyLabel);

//            // Значение для каждого свойства
//            QTableWidgetItem *valueItem = new QTableWidgetItem(getValueForProperty(property));
//            tableWidget->setItem(row, 1, valueItem);
//        }

//        // Автоматическая подгонка ширины колонок
//        tableWidget->resizeColumnsToContents();

//        // Создание и настройка основного макета
//        QVBoxLayout *layout = new QVBoxLayout(centralWidget);
//        layout->addWidget(tableWidget);

//        // Установка основного макета
//        centralWidget->setLayout(layout);
//}

//QString MyMainWindow::getValueForProperty(const QString &property) const
//{
//
//    if (property == "Вася") {
//        return "555";
//    } else if (property == "Петя") {
//        return "888";
//    } else if (property == "Дата и время отправки") {
//        return "333";
//    }
//    //
//    return "";
//}
      //  void setupUI(const QStringList& properties, const QStringList& values) {
            // Создание основного виджета
            QWidget *centralWidget = new QWidget(this);
            setCentralWidget(centralWidget);

            // Создание TableWidget с двумя колонками
            QTableWidget *tableWidget = new QTableWidget(0, 2, this);
            QStringList headerLabels = {"Свойство", "Значение"};
            tableWidget->setHorizontalHeaderLabels(headerLabels);

            // Добавление свойств и значений в TableWidget
            int rowCount = qMin(properties.size(), values.size());
            for (int i = 0; i < rowCount; ++i) {
                int row = tableWidget->rowCount();
                tableWidget->insertRow(row);

                // Лейбл для свойства
                QLabel *propertyLabel = new QLabel(properties[i]);
                tableWidget->setCellWidget(row, 0, propertyLabel);

                // Значение для каждого свойства
                QTableWidgetItem *valueItem = new QTableWidgetItem(values[i]);
                tableWidget->setItem(row, 1, valueItem);
            }

            // Автоматическая подгонка ширины колонок
            tableWidget->resizeColumnsToContents();

            // Создание и настройка основного макета
            QVBoxLayout *layout = new QVBoxLayout(centralWidget);
            layout->addWidget(tableWidget);

            // Установка основного макета
            centralWidget->setLayout(layout);
        }
