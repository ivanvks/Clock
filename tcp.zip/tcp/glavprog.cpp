// main.cpp
#include <QCoreApplication>
#include "server.h"
#include "client.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    // Создаем и запускаем сервер
    Server server;
    if (!server.listen(QHostAddress::Any, 12345))
    {
        qDebug() << "Server could not start!";
        return 1;
    }

    qDebug() << "Server listening on port 12345";

    // Создаем клиента и подключаем его к серверу
    Client client;
    client.connectToServer();

    return a.exec();
}
