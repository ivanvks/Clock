#ifndef MYMAINWINDOW_H
#define MYMAINWINDOW_H

#include <QMainWindow>

class MyMainWindow : public QMainWindow {
public:
    MyMainWindow(int messageCount);

private:
    void setupUI(int messageCount);
};

#endif // MYMAINWINDOW_H
