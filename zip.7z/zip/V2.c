QByteArray CSqlDatabase::selectFromInMSGKSI(const QString &msgType) {
    // Создаем пустой вектор данных
    QByteArray dataVector;
    // Инициализируем запрос к базе данных
    QSqlQuery sqlQuery(mASUVDataBase_);
    // Задаем запрос к базе данных, включая выражение RETURNING
    sqlQuery.prepare("UPDATE in_msg_buff SET zip = true WHERE msg_id IN ("
                     "  SELECT in_msg_buff.msg_id FROM in_msg_data, in_msg_buff "
                     "  WHERE in_msg_buff.msg_id = in_msg_data.msg_id "
                     "    AND in_msg_buff.msg_type = :msgType AND in_msg_buff.zip = false "
                     "  LIMIT 1"
                     ") RETURNING in_msg_data.msg_data");
    // Задаем тип сообщения
    sqlQuery.bindValue(":msgType", msgType);
    // Выполняем запрос к базе данных
    if (!sqlQuery.exec()) {
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
        // Возвращаем пустой вектор данных
        return dataVector;
    }

    // Получаем сообщение
    if (sqlQuery.next()) {
        // Задаем вектор данных
        dataVector = sqlQuery.value(0).toByteArray();
        // Посылаем сигнал о выборке сообщения
        qDebug() << __PRETTY_FUNCTION__ << msgType << "!!!!!!!!!!!!!!!!!!!!!!!!!";
        // Сигнал счетчика
        emit inSignalOnDeleteMSGKsi(msgType);
    }

    // Возвращаем вектор данных
    return dataVector;
}
