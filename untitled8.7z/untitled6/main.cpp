#include "mainwindow.h"

#include <QApplication>

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    // Количество входящих сообщений
    int messageCount = 5;


    QStringList properties = {"Вася", "Петя", "Дата и время отправки",
                              "Наименование", "Дата и время получения", "Статус",
                              "Дата и время прочтения", "Комментарии"};

    QStringList values = {"555", "888", "333", "Value4", "Value5", "Value6", "Value7", "Value8"};

    MyMainWindow mainWindow(messageCount, properties, values);
    mainWindow.show();

    return app.exec();




}
