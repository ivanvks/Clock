QByteArray CSqlDatabase::selectFromInMSGKSI(const QString &msgType) {
    // Создаем пустой вектор данных
    QByteArray dataVector;
    // Инициализируем запрос к базе данных
    QSqlQuery sqlQuery(mASUVDataBase_);
    // Задаем запрос к базе данных
    sqlQuery.prepare("SELECT in_msg_buff.msg_id, in_msg_data.msg_data FROM "
                     "in_msg_data, in_msg_buff "
                     "WHERE in_msg_buff.msg_id = in_msg_data.msg_id AND in_msg_buff.msg_type = :msgType AND in_msg_buff.zip = false "
                     "LIMIT 1");
    // Задаем тип сообщения
    sqlQuery.bindValue(":msgType", msgType);
    // Выполняем запрос к базе данных
    if (!sqlQuery.exec()) {
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
        // Возвращаем пустой вектор данных
        return dataVector;
    }

    QStringList idLst; // Инициализируем список индексов обработанных сообщений
    // Получаем сообщения
    while (sqlQuery.next()) {
        // Задаем вектор данных
        dataVector.append(sqlQuery.value(1).toByteArray());
        // Задаем индексы обработанных сообщений
        idLst.append(sqlQuery.value(0).toString());
    }

    // Помечаем выбранные сообщения как прочитанные
    for (const QString& msgId : idLst) {
        QSqlQuery updateQuery;
        updateQuery.prepare("UPDATE in_msg_buff SET zip = true WHERE msg_id = :msgId");
        updateQuery.bindValue(":msgId", msgId);
        if (!updateQuery.exec()) {
            qDebug() << "Failed to mark message as read:" << updateQuery.lastError();
            // Обработка ошибки при неудачном выполнении запроса UPDATE
        }
    }

    // Посылаем сигнал о выборке сообщения
    qDebug() << __PRETTY_FUNCTION__ << msgType << "!!!!!!!!!!!!!!!!!!!!!!!!!";
    // Сигнал счетчика
    emit inSignalOnDeleteMSGKsi(msgType);
    // Возвращаем вектор данных
    return dataVector;
}
